
def hello(func):
    func()
    
def greet():
    print("Hello!")
    
hello(greet)

# this example shows us that functions can also be used as variables.
