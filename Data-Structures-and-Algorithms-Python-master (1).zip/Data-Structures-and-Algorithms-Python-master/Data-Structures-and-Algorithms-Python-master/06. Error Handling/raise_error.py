
# we can stop the program by raising our own errors.

print("Hello!!!!")
# raise TypeError("yo")
raise Exception("Any message ")
print("bye")
