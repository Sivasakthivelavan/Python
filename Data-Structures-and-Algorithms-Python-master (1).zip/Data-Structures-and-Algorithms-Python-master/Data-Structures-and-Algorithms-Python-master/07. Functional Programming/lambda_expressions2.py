

a = [(0,2),(4,4),(10,-1),(5,3)]

a.sort(key=lambda x:x[1], reverse=False)
print(a)
